package com.example.amalalhinai.htcare;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity {


    private TextView username;
    private TextView passwod;
    private Button login;
    private TextView regester;
    private TextView btnforgetPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        username = (TextView) findViewById(R.id.etUser);
       passwod = (TextView) findViewById(R.id.etPass);
       login = (Button) findViewById(R.id.btn_Login);
        btnforgetPass = (TextView) findViewById(R.id.forgetPass);
      regester = (TextView) findViewById(R.id.register);
      regester.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login.this, RegisterCampaign.class);

               startActivity(intent);
          }
       });
      btnforgetPass.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Intent intent = new Intent(Login.this, RestPassword.class);

              startActivity(intent);
          }
      });
      login.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {

              if ((username.getText().toString()) =="admin@gmail.com"){
                  Intent intent = new Intent(Login.this, RegisterCampaign.class);
                  startActivity(intent);
              }else if ((passwod.getText().toString()) .equals("Tour@123")){
                  Intent intent = new Intent(Login.this, Tour.class);

                  startActivity(intent);
              }else {

              }
          }
      });
    }

}
