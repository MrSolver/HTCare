package com.example.amalalhinai.htcare;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;

public class RegisterCampaign extends AppCompatActivity {

    private Button mRegister;
    private EditText compaaignName;
    private EditText compaaignEmail;
    private EditText compaaignPass;
    private EditText compaaignConfirmPass;
    private EditText compaaignPhone;
    private EditText name;
    private EditText compaaignNumberLicense;
    private EditText compaaignNumberBus;
    private EditText compaaignNumberHajj;
    private FirebaseAuth mAuth;
    private DatabaseReference myRef;
    private String registerId;
    private Button mLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_campaign);


        mRegister = (Button) findViewById(R.id.btn_signup);
        mLogin = (Button) findViewById(R.id.btn_link_login);
        name = (EditText) findViewById(R.id.input_name);
        compaaignEmail = (EditText) findViewById(R.id.input_email);
        compaaignPass = (EditText) findViewById(R.id.input_pass);
        compaaignConfirmPass = (EditText) findViewById(R.id.input_confi_pass);
        compaaignPhone = (EditText) findViewById(R.id.input_phone);
        compaaignName = (EditText) findViewById(R.id.input_campaign_name);
        compaaignNumberLicense = (EditText) findViewById(R.id.input_number_license);
        compaaignNumberBus = (EditText) findViewById(R.id.input_number_bus);
        compaaignNumberHajj = (EditText) findViewById(R.id.input_number_hajj);



        mAuth = FirebaseAuth.getInstance();
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("RegisterCompaign");
        mRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(name.getText().toString())) {
                    name.setError("The name can't be empty");
                    return;
                }


                if (TextUtils.isEmpty(compaaignName.getText().toString())) {
                    compaaignName.setError("The last name can't be empty");
                    return;
                }

                if (TextUtils.isEmpty(compaaignNumberLicense.getText().toString())) {
                    compaaignNumberLicense.setError("The ID can't be empty");
                    return;
                }

                if (TextUtils.isEmpty(compaaignPhone.getText().toString())) {
                    compaaignPhone.setError("The phone number can't be empty");
                    return;
                }
                if (TextUtils.isEmpty(compaaignPass.getText().toString())) {
                    compaaignPass.setError("The password can't be empty");
                    return;
                }
                if (TextUtils.isEmpty(compaaignConfirmPass.getText().toString())) {
                    compaaignConfirmPass.setError("The confirm password can't be empty");
                    return;
                }
                if (TextUtils.isEmpty(compaaignEmail.getText().toString())) {
                    compaaignEmail.setError("The email can't be empty");
                    return;
                } if (TextUtils.isEmpty(compaaignNumberHajj.getText().toString())) {
                    compaaignNumberHajj.setError("The last name can't be empty");
                    return;
                }

                if (TextUtils.isEmpty(compaaignNumberBus.getText().toString())) {
                    compaaignNumberBus.setError("The ID can't be empty");
                    return;
                }
                else {

                    {
                        mAuth.createUserWithEmailAndPassword(compaaignEmail.getText().toString(), compaaignPass.getText().toString())
                                .addOnCompleteListener(RegisterCampaign.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        Log.d("ITA", "createUserWithEmail:onComplete:" + task.isSuccessful());

                                        // If sign in fails, display a message to the user. If sign in succeeds
                                        // the auth state listener will be notified and logic to handle the
                                        // signed in user can be handled in the listener.
                                        if (!task.isSuccessful()) {
                                            Toast.makeText(RegisterCampaign.this, "Authentication failed.",
                                                    Toast.LENGTH_SHORT).show();


                                        } else {
                                            if ((compaaignPass.getText().toString()).equals(compaaignConfirmPass.getText().toString())) {
                                                Toast.makeText(RegisterCampaign.this, "Authentication success.",
                                                        Toast.LENGTH_SHORT).show();
                                                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                                registerId = myRef.push().getKey();
                                                // registerId = user.getUid();
                                                RegisterInfoCampaign userRegister = new RegisterInfoCampaign();
                                                userRegister.setName(name.getText().toString());
                                                userRegister.setNameCampaign(compaaignName.getText().toString());
                                                userRegister.setNumberLicense(compaaignNumberLicense.getText().toString());
                                                userRegister.setPhone(compaaignPhone.getText().toString());
                                                userRegister.setPasswor(compaaignPass.getText().toString());
                                                userRegister.setConfirmPassword(compaaignConfirmPass.getText().toString());
                                                userRegister.setEmail(compaaignEmail.getText().toString());


                                                userRegister.setRegisterId(user.getUid());
                                                userRegister.setDeviceID(FirebaseInstanceId.getInstance().getToken());
                                                myRef.child(user.getUid()).setValue(userRegister);

                                                Toast.makeText(RegisterCampaign.this, "Register Successfully", Toast.LENGTH_SHORT).show();
                                                startActivity(new Intent(RegisterCampaign.this, Login.class));
                                            } else {
                                                Toast.makeText(RegisterCampaign.this, "passwords not matching.please try again", Toast.LENGTH_SHORT).show();
                                            }
                                        }

                                        // ...
                                    }
                                });
                    }
                }
            }
        });
        mLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterCampaign.this, Login.class));

            }
        });
    }
}
