package com.example.amalalhinai.htcare;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class AddCampany extends AppCompatActivity {

    private Button mRegisterCampany;
    private Button mLoginCampany;
    private EditText nameCampany;
    private EditText EmailCampany;
    private EditText passCampany;
    private EditText confirmPassCampany;
    private EditText phoneCampany;
    private EditText location;
    private EditText price;
    private RadioGroup service;
    private RadioButton radioHotel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_campany);


        mRegisterCampany = (Button) findViewById(R.id.btn_signup_campany);
        mLoginCampany = (Button) findViewById(R.id.btn_link_login_campany);
        nameCampany = (EditText) findViewById(R.id.input_name_campany);
        EmailCampany = (EditText) findViewById(R.id.input_email_campany);
        confirmPassCampany = (EditText) findViewById(R.id.input_confi_pass_campany);
        phoneCampany = (EditText) findViewById(R.id.input_phone_campany);
        location = (EditText) findViewById(R.id.input_location);
        price = (EditText) findViewById(R.id.input_price);
        service = (RadioGroup) findViewById(R.id.serviceRadioGroup);
        radioHotel = (RadioButton) findViewById(R.id.radio_hotel);


    }
}
